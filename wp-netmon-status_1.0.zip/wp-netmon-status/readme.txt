=== Plugin Name ===
Contributors: TinoD
Tags: widget, netmon, freifunk
Requires at least: 4.0.1
Tested up to: 4.0.1
License: GPLv3
License URI: https://github.com/StilgarBF/wp-netmon-status/blob/master/LICENSE.txt

Shows Netmon-Stats as a widget.

== Description ==

Shows networkinformations from (Freifunk)Netmon as a Wordpress-Widget.
The plugin will use the REST-API to collect informations about routers that are online or offline and connected clients and show the numpers in a Widget.

See Widget-Demo at http://www.freifunk-emskirchen.de/

for netmon see https://git.nordwest.freifunk.net/root/netmon

== Installation ==

1. Upload the plugin-directory to your Wordpress-plugin folder.
1. Activate the plugin through the 'Plugins' menu in WordPress
1. In Design -> Widgets add the Widget where you want it to be
1. Configure the Widget by adding your netmon-url like "https://netmon.my-freifunk.de/"

== Screenshots ==

1. the widget

== Changelog ==

= 1.0 =
* Initial release

