wp-netmon-status
================

Shows networkinformations from (Freifunk)Netmon as a Wordpress-Widget.

See Widget at http://www.freifunk-emskirchen.de/

for netmon see https://git.nordwest.freifunk.net/root/netmon
